"""
LLM 서비스 설정 관리 모듈

이 모듈은 APE의 LLM 서비스 연결 설정을 관리합니다.
"""

import os
import logging
import json
from typing import Dict, Any, List, Optional, Union
from pathlib import Path

from src.core.env_loader import get_env, get_boolean_env, get_int_env, get_float_env

# 로거 설정
logger = logging.getLogger("network_config")

# LLM 서비스 설정
LLM_ENDPOINT = get_env("LLM_ENDPOINT", "http://llm-service/api")
LLM_API_KEY = get_env("LLM_API_KEY", "")
LLM_TIMEOUT = get_int_env("LLM_TIMEOUT", 30)
LLM_VERIFY_SSL = get_boolean_env("LLM_VERIFY_SSL", False)

# 백업 LLM 서비스 설정 (OpenRouter)
OPENROUTER_ENDPOINT = get_env("OPENROUTER_ENDPOINT", "https://openrouter.ai/api/v1/chat/completions")
OPENROUTER_API_KEY = get_env("OPENROUTER_API_KEY", "")
OPENROUTER_TIMEOUT = get_int_env("OPENROUTER_TIMEOUT", 30)

# 서비스 설정 함수들
def get_llm_config() -> Dict[str, Any]:
    """LLM 서비스 설정 반환"""
    return {
        "endpoint": LLM_ENDPOINT,
        "api_key": LLM_API_KEY,
        "timeout": LLM_TIMEOUT,
        "verify_ssl": LLM_VERIFY_SSL
    }

def get_openrouter_config() -> Dict[str, Any]:
    """OpenRouter LLM 설정 반환"""
    return {
        "endpoint": OPENROUTER_ENDPOINT,
        "api_key": OPENROUTER_API_KEY,
        "timeout": OPENROUTER_TIMEOUT
    }

def get_network_info() -> Dict[str, Any]:
    """현재 네트워크 설정 정보 반환"""
    return {
        "primary": {
            "llm_endpoint": LLM_ENDPOINT,
            "llm_api_key_set": bool(LLM_API_KEY),
            "timeout": LLM_TIMEOUT
        },
        "backup": {
            "openrouter_endpoint": OPENROUTER_ENDPOINT,
            "openrouter_api_key_set": bool(OPENROUTER_API_KEY),
            "timeout": OPENROUTER_TIMEOUT
        }
    }