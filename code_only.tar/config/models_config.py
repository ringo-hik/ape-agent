"""
통합 LLM 모델 구성

이 파일은 모든 LLM 모델 설정을 정의합니다.
모델은 URL 기반으로 접근하며, 연결할 수 없는 경우 자동으로 실패합니다.
"""

from src.core.env_loader import get_env, get_int_env, get_float_env, get_boolean_env

# 모델 구성
MODELS = {
    "primary": {
        "name": "기본 LLM 모델",
        "id": "primary-model-v1",
        "description": "기본 LLM 서비스 모델",
        "provider": "primary",
        "endpoint": get_env("LLM_ENDPOINT", "http://llm-service/api"),
        "apiKey": get_env("LLM_API_KEY", ""),
        "maxTokens": get_int_env("LLM_MAX_TOKENS", 4096),
        "temperature": get_float_env("LLM_TEMPERATURE", 0.7),
        "requestTemplate": {
            "headers": {
                "Authorization": "Bearer ${API_KEY}",
                "Content-Type": "application/json"
            },
            "payload": {
                "model": "primary-model-v1",
                "max_tokens": 4096,
                "temperature": "${TEMPERATURE}",
                "stream": "${STREAM}",
                "messages": []
            }
        }
    },
    "korean": {
        "name": "한국어 LLM 모델",
        "id": "korean-model-v1",
        "description": "한국어 특화 LLM 서비스 모델",
        "provider": "primary",
        "endpoint": get_env("LLM_KO_ENDPOINT", "http://llm-ko-service/api"),
        "apiKey": get_env("LLM_KO_API_KEY", ""),
        "maxTokens": get_int_env("LLM_KO_MAX_TOKENS", 4096),
        "temperature": get_float_env("LLM_KO_TEMPERATURE", 0.7),
        "requestTemplate": {
            "headers": {
                "Authorization": "Bearer ${API_KEY}",
                "Content-Type": "application/json"
            },
            "payload": {
                "model": "korean-model-v1",
                "max_tokens": 4096,
                "temperature": "${TEMPERATURE}",
                "stream": "${STREAM}",
                "messages": []
            }
        }
    },
    "embedding": {
        "name": "임베딩 모델",
        "id": "embedding-model-v1",
        "description": "텍스트 임베딩 서비스 모델",
        "provider": "primary",
        "endpoint": get_env("EMBEDDING_ENDPOINT", "http://embedding-service/api"),
        "apiKey": get_env("EMBEDDING_API_KEY", ""),
        "maxTokens": 0,  # 임베딩 모델은 max_tokens가 필요 없음
        "temperature": 0.0,  # 임베딩 모델은 temperature가 필요 없음
        "requestTemplate": {
            "headers": {
                "Authorization": "Bearer ${API_KEY}",
                "Content-Type": "application/json"
            },
            "payload": {
                "model": "embedding-model-v1",
                "input": [],
                "encoding_format": "float"
            }
        }
    },
    "openrouter-llama": {
        "name": "OpenRouter Llama3",
        "id": "meta/llama-3-70b-instruct",
        "description": "OpenRouter를 통한 Llama3 70B 모델",
        "provider": "openrouter",
        "endpoint": get_env("OPENROUTER_ENDPOINT", "https://openrouter.ai/api/v1/chat/completions"),
        "apiKey": get_env("OPENROUTER_API_KEY", ""),
        "maxTokens": get_int_env("OPENROUTER_MAX_TOKENS", 4096),
        "temperature": get_float_env("OPENROUTER_TEMPERATURE", 0.7),
        "requestTemplate": {
            "headers": {
                "Authorization": "Bearer ${API_KEY}",
                "HTTP-Referer": "APE-Core-API",
                "X-Title": "APE (Agentic Pipeline Engine)",
                "Content-Type": "application/json"
            },
            "payload": {
                "model": "meta/llama-3-70b-instruct",
                "max_tokens": 4096,
                "temperature": "${TEMPERATURE}",
                "stream": "${STREAM}",
                "messages": []
            }
        }
    },
    "openrouter-mixtral": {
        "name": "OpenRouter Mixtral",
        "id": "mistralai/mixtral-8x7b-instruct",
        "description": "OpenRouter를 통한 Mixtral 8x7B 모델",
        "provider": "openrouter",
        "endpoint": get_env("OPENROUTER_ENDPOINT", "https://openrouter.ai/api/v1/chat/completions"),
        "apiKey": get_env("OPENROUTER_API_KEY", ""),
        "maxTokens": get_int_env("OPENROUTER_MAX_TOKENS", 4096),
        "temperature": get_float_env("OPENROUTER_TEMPERATURE", 0.7),
        "requestTemplate": {
            "headers": {
                "Authorization": "Bearer ${API_KEY}",
                "HTTP-Referer": "APE-Core-API",
                "X-Title": "APE (Agentic Pipeline Engine)",
                "Content-Type": "application/json"
            },
            "payload": {
                "model": "mistralai/mixtral-8x7b-instruct",
                "max_tokens": 4096,
                "temperature": "${TEMPERATURE}",
                "stream": "${STREAM}",
                "messages": []
            }
        }
    }
}

# 기본 모델 키
DEFAULT_MODEL = "primary"
DEFAULT_BACKUP_MODEL = "openrouter-llama"

def get_models():
    """모든 모델 구성 반환"""
    return MODELS

def get_default_model():
    """기본 모델 키 반환"""
    return DEFAULT_MODEL

def get_default_backup_model():
    """기본 백업 모델 키 반환"""
    return DEFAULT_BACKUP_MODEL

def get_model_config(model_key):
    """모델 구성 반환"""
    models = get_models()
    return models.get(model_key, models.get(DEFAULT_MODEL))